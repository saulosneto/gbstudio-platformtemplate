Place plugin folders in this folder to extend the capabilities of your game

Docs: https://www.gbstudio.dev/docs/extending-gbstudio/plugins
