Place .uge and .mod files in this folder to use them as music in your game

Docs: https://www.gbstudio.dev/docs/assets/music/
